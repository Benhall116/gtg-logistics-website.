GTG LOGISTICS & COURIER SERVICES — WEBSITE STARTER

WHAT'S INCLUDED
- index.html: responsive homepage for dispatch services, local deliveries, state-to-state loads, driver recruitment, and inquiries.
- assets/gtg-gorilla-logo.jpg: your uploaded GTG gorilla logo.
- assets/driver-recruitment-flyer.png: your uploaded recruitment flyer.

PREVIEW ON A PHONE OR COMPUTER
1. Extract the ZIP file.
2. Keep the assets folder in the same folder as index.html.
3. Open index.html in a web browser.

CONTACT DETAILS ALREADY INCLUDED
Phone/text: (614) 316-8518
Email: gtglogisticsndispatch@gmail.com

INQUIRY FORM — IMPORTANT
The form validates the visitor's entries and opens a prefilled email addressed to your GTG email. The visitor must press Send. It does not automatically email you, save leads to a database, or provide a private dashboard. The visitor needs an email app/account configured for this to work smoothly. For automatic lead capture, connect and test a form backend/service before relying on it for business leads.

FREE PUBLISHING OPTION (GITHUB PAGES)
1. Sign in or create a GitHub account.
2. Create a new public repository, for example: gtg-logistics-website.
3. Upload index.html and the complete assets folder (not just the image files).
4. Open the repository's Settings, then Pages.
5. Under Build and deployment, choose Deploy from a branch; select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish. The Pages screen will show the live website URL. Open it on your phone and test every navigation link, phone link, email link, and the inquiry form.

A custom domain is optional. GitHub Pages is free for public repositories under its applicable terms, but hosting terms and features can change. Do not upload private customer information or confidential business records into the repository.

BEFORE OFFERING LOGISTICS SERVICES
This website is a marketing starter, not a legal or regulatory determination. Confirm the business's applicable registrations, operating authority, insurance, contracts, and any carrier/broker requirements before advertising or performing regulated services. Do not promise guaranteed loads, income, or rates unless you can substantiate them in writing.

CUSTOMIZATION
Edit index.html in a text editor to change website wording, services, or contact information. Keep the assets folder beside index.html. Test on mobile and desktop after every change.
